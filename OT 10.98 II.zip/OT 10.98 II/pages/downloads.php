<img id="ContentBoxHeadline" class="Title" src="layouts/tibiacom/images/header/headline-downloadclient.gif" alt="Contentbox headline">
<?PHP
$main_content .= '
   <div class="TableContainer" >
 <table class="Table4" cellpadding="0" cellspacing="0" >
   <div class="CaptionContainer" >
     <div class="CaptionInnerContainer" >
       <span class="CaptionEdgeLeftTop" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>
       <span class="CaptionEdgeRightTop" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>  
     <span class="CaptionBorderTop" style="background-image:url(https://static.tibia.com/images/global/content/table-headline-border.gif);" >
</span>
       <span class="CaptionVerticalLeft" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-vertical.gif);" />
</span>  
     <div class="Text" >Download Client</div>
       <span class="CaptionVerticalRight" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-vertical.gif);" />
</span>
      <span class="CaptionBorderBottom" style="background-image:url(https://static.tibia.com/images/global/content/table-headline-border.gif);" >
</span>    
   <span class="CaptionEdgeLeftBottom" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>
       <span class="CaptionEdgeRightBottom" style="background-image:url(https://static.tibia.com/images/global/content/box-frame-edge.gif);" />
</span>
     </div>
   </div>
   <tr>  
   <td>
      <div class="InnerTableContainer" >      
   <table style="width:100%;" >
<tr>
<td>
<table width="100%" cellpadding=0 cellspacing=0><tr><td style="vertical-align:top" >
<div class="TableShadowContainerRightTop" >
<div class="TableShadowRightTop" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rt.gif);" >
</div>
</div>
<div class="TableContentAndRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rm.gif);" >
 <div class="TableContentContainer" >
   <table class="TableContent" width="100%" >
<tr>
<td>
<table style="width:100%;text-align:center" >
<tr>
<td>
 <img style="width:180;height:180px;border:0px;" src="layouts/united/images/content/download_windows.gif" />
</a>
</td>
<td>
<img style="width:180;height:180px;border:0px;" src="layouts/united/images/content/download_ipchanger.png" />
<br/>
</a>
</td>
</tr>
<tr>
<td valign="top" >
<a href="#" type="http://167.114.21.75/materiaglobal.rar" type="application/octet-stream" target="_top" >LINK ABAIXO \/</a>
</td>
<td valign="top" >
<a href="http://static.otland.net/ipchanger.exe" target="_top" >IP Changer 10.92</a>
</td>
</tr>
<tr>
</td>
<tr>
</table>
</tr>
</table>
 
</table>
 
<div class="TableShadowContainer" >  <div class="TableBottomShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bm.gif);" >
   <div class="TableBottomLeftShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bl.gif);" >
</div>
  <div class="TableBottomRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-br.gif);" >
 
 </div>
</div>
</td>

</tr>
<div class="TableShadowContainerRightTop" >
 <div class="TableShadowRightTop" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rt.gif);" >
</div></table>
<div class="TableContentAndRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-rm.gif);" >
 <div class="TableContentContainer" >
   <table class="TableContent" width="100%" >
 
<td class="LabelV" >Download</td>
</tr>
 
<td> http://www.mediafire.com/download/832yk831hd282q4/materia-global.rar </td>
   </table>
 </div>
</div>
<div class="TableShadowContainer" >
 <div class="TableBottomShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bm.gif);" >
   <div class="TableBottomLeftShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-bl.gif);" >
</div>
   <div class="TableBottomRightShadow" style="background-image:url(https://static.tibia.com/images/global/content/table-shadow-br.gif);" >
</div></table></table></table></div></table></table></table></table></table></table>
 ';